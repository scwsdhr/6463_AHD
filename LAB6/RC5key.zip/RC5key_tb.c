#include "RC5key.h"

int main() {
    // input key value in unsigned char
    unsigned char key[b];
    // input key value in hexadecimal bit string
    char key_in[w + 1];  // there is a '\0' in the end
    // loop variable
    int i;
    // hardcode 96 most significant bits of key (in hexadecimal)
    char key_hardcode[t + 1] =
        "000000000000000000000000";  // there is a '\0' in the end
    // user input 32 bits of key (in hexadecimal)
    char key_user[9];  // there is a '\0' in the end

    // you can either enter them one by one or use a for loop
    // put the user determined 32 bits of key here
    strcpy(key_user, "FFFFFFFF");
    strcpy(key_in, key_hardcode);
    strcat(key_in, key_user);
    for (i = 0; i < b; i++) sscanf(key_in + 2 * i, "%02X", &key[i]);

#ifdef __KEY_EXPANSION__
    RC5_SETUP(key);
#endif

#ifdef __RC5_GENERAL__
    char v1[8];
    char v2[8];
    WORD val1;
    WORD val2;

    strcpy(v1, "00000000");
    strcpy(v2, "00000000");
    val1 = (int)strtol(v1, NULL, 16);
    val2 = (int)strtol(v2, NULL, 16);

    RC5(key, val1, val2);
#endif

    return 0;
}
