$Footmark = "FPGA_Xilinx"
$Description = "by Vivado"


#=== Resource usage ===
$SLICE = "9"
$LUT = "22"
$FF = "38"
$DSP = "0"
$BRAM ="0"
$SRL ="0"
#=== Final timing ===
$TargetCP = "10.000"
$CP = "3.552"
