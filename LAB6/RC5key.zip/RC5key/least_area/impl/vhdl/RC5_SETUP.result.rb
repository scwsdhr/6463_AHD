$Footmark = "FPGA_Xilinx"
$Description = "by Vivado"


#=== Resource usage ===
$SLICE = "9"
$LUT = "23"
$FF = "33"
$DSP = "0"
$BRAM ="0"
$SRL ="0"
#=== Final timing ===
$TargetCP = "10.000"
$CP = "3.569"
